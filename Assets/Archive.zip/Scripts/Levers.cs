using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Levers : MonoBehaviour
{
    bool leverState = false;
    [SerializeField] int leverNumber = 0;

    public void WhatLever()
    {
        switch (leverNumber)
        {
            case 0: //lever 1
                Debug.Log(gameObject.name);
                if (leverState == false)
                {
                    PutLeverUp();
                    Debug.Log("Lever1 up");
                }
                if(leverState == true)
                {
                    PutLeverDown();
                    Debug.Log("Lever2 up");
                }
                break;
            case 1: //lever 2
                Debug.Log(gameObject.name);
                if (leverState == false)
                {
                    PutLeverUp();
                    Debug.Log("Lever2 up");
                }
                if (leverState == true)
                {
                    PutLeverDown();
                    Debug.Log("Lever2 up");
                }
                break;
            case 2: //lever 2
                Debug.Log(gameObject.name);
                if (leverState == false)
                {
                    PutLeverUp();
                }
                if (leverState == true)
                {
                    PutLeverDown();
                }
                break;
            default:
                
                break;
        }
        //particles
        //sound
        //correct sound

    }

    private void PutLeverUp()
    {
        leverState = true;
        //animation
    }

    private void PutLeverDown()
    {
        leverState = false;
        //animation
    }
}
