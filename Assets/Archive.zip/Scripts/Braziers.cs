using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Braziers : MonoBehaviour
{
    [SerializeField] int brazierNumber = 0;

    public void WhatBrazier()
    {
        switch (brazierNumber)
        {
            case 0: //brazier 1
                Debug.Log(gameObject.name);
                break;
            case 1: //brazier 2
                Debug.Log(gameObject.name);
                break;
            case 2: //brazier 2
                Debug.Log(gameObject.name);
                break;
            default:
                
                break;
        }

        //particles
        //sound

    }
}
