using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Torch : MonoBehaviour
{
    [SerializeField] int torchNumber = 0;

    public void WhatTorch()
    {
        switch (torchNumber)
        {
            case 0: //torch 1
                Debug.Log("test1");
                break;
            case 1: //torch 2
                Debug.Log("test2");
                break;
            case 2: //torch 3
                Debug.Log("test3");
                break;
            default:
                Debug.Log("default");
                break;
        }
        //particles
        //sound
    }
}
